function sonuc = steadyState( kume , x, y, rnd, energy, dead_nodes, operating_nodes, nn_output)

Eelec=50*10^(-9); % units in nanoJoules/bit
ETx=50*10^(-9); % units in Joules/bit
ERx=50*10^(-9); % units in Joules/bit
Eamp=100*10^(-12); % units in pikoJoules/bit/m^2 (amount of energy spent by the amplifier to transmit the bits)
EDA=5*10^(-9); % units in Joules/bit
k=4000; % units in bits

%kume icin CH secimini Gerceklestirelim%
CH=0;
[M,CH]=max(nn_output(:)); % finds the maximum fitness node to CH
kume(CH).role=1;
kume(CH).rn=rnd;	% Assigns the round that the cluster head was elected to the data table
kume(CH).tel=kume(CH).tel + 1; %kac kere ch secildi
kume(CH).dist_s=sqrt((kume(CH).sinkx-kume(CH).x)^2 + (kume(CH).sinkx-kume(CH).y)^2); % calculates the distance between the sink and the cluster hea


for i=1:length(kume)
    if  ((kume(i).role==0) & (kume(i).E>0)  & (kume(i).cond==1)) % if node is normal
        kume(i).dist_ch=sqrt((kume(CH).x-kume(i).x)^2 + (kume(CH).y-kume(i).y)^2);
        kume(i).chid=CH;
    end
end

%Kume icin Enerji Harcama%
for i=1:length(kume)
    if ((kume(i).cond==1) & (kume(i).role==0))
        if kume(i).E>0
            %Sensorlerin veri gondermede harcadiklari enerji
            ETx= Eelec*k + Eamp * k * kume(i).dist_ch^2;
            kume(i).E=kume(i).E - ETx;
            energy=energy+ETx;
            % CH icin veri toplamada harcanan enerji
            if ((kume(kume(i).chid).E>0) & (kume(kume(i).chid).cond==1) & (kume(kume(i).chid).role==1))
                ERx=(Eelec+EDA)*k;
                energy=energy+ERx;
                kume(kume(i).chid).E=kume(kume(i).chid).E - ERx;
                if kume(kume(i).chid).E<=0  % if cluster heads energy depletes with reception
                    kume(kume(i).chid).cond=0;
                    kume(kume(i).chid).rop=rnd;
                    dead_nodes=dead_nodes +1;
                    operating_nodes= operating_nodes - 1
                end
            end
        end
        
        if kume(i).E<=0       % if nodes energy depletes with transmission
            dead_nodes=dead_nodes +1;
            operating_nodes= operating_nodes - 1
            kume(i).cond=0;
            kume(i).chid=0;
            kume(i).rop=rnd;
        end
        
    elseif((kume(i).cond==1)  & (kume(i).role==1))
        if kume(i).E>0
            ETx= (Eelec+EDA)*k + Eamp * k * kume(i).dist_s^2;
            kume(i).E=kume(i).E - ETx;
            energy=energy+ETx;
        end
        if  kume(i).E<=0     % if cluster heads energy depletes with transmission
            dead_nodes=dead_nodes +1;
            operating_nodes= operating_nodes - 1
            kume(i).cond=0;
            kume(i).rop=rnd;
        end
    end
end
kume(1).energy=energy;
kume(1).dead_nodes=dead_nodes;
kume(1).operating_nodes=operating_nodes;

sonuc=kume;
end

