function cluster = createCluster(xm,ym)
gridCounter=1;
stun=ym/30;
satr=xm/30;

for i=1:stun
    for j=1:satr
        clusterSet(gridCounter).ID = gridCounter;   
        clusterSet(gridCounter).tempsecretID = [num2str(j),num2str(i)];
        clusterSet(gridCounter).secretID = [str2num(clusterSet(gridCounter).tempsecretID)];
        clusterSet(gridCounter).X = j * 30;
        clusterSet(gridCounter).Y = i * 30;
        clusterSet(gridCounter).centerX = clusterSet(gridCounter).X - 15;
        clusterSet(gridCounter).centerY = clusterSet(gridCounter).Y - 15;
        gridCounter=gridCounter+1;
    end
end

cluster=clusterSet;
end



    