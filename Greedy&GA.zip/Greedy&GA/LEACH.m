close all;
clear;
clc;
%Parametreler%
nGrid = 2; %Grid yap�s� NxN
clstr = 12;
mySensorX = 0;
mySensorY = 0;
n=1000; %Sensor Sayisi
xm=120; %x duzlemi
ym=90; %y duzlemi
x=0;
y=0;
dead_nodes=0; %Olu Sensor Sayisi
sinkx=20;
sinky=20;
Eo=2; %Baslangic Enerjisi
Eelec=50*10^(-9); % units in nanoJoules/bit
ETx=50*10^(-9); % units in Joules/bit
ERx=50*10^(-9); % units in Joules/bit
Eamp=100*10^(-12); % units in pikoJoules/bit/m^2 (amount of energy spent by the amplifier to transmit the bits)
EDA=5*10^(-9); % units in Joules/bit
k=4000; % units in bits
rnd=0;
operating_nodes=n;
transmissions=0;
temp_val=0;
flag1stdead=0;
a=1;
residual_energy=n*Eo;
sink_energy=0;
total_energy=0;
%Parametre Sonu%

%Baslangic Durumu%
% SN=createSensors(n,xm,ym); % Sensorler olusturuluyor
%
% CLSTR=createCluster(nGrid); % Kumeler olusturuluyor
%
% %sensorlerin hangi kumeye ait olduklar�n� buluyoruz%
% for i=1:n
%     mySensorX = SN(i).x;
%     mySensorY = SN(i).y;
%
%     x = fix(mySensorX / 30);
%     y = fix(mySensorY / 30);
%
%     secretid=[num2str(x+1),num2str(y+1)];
%
%     for j=1:clstr
%         if(CLSTR(j).secretID == secretid)
%             SN(i).E = Eo; %dugumlere baslangic enerjisi atiyoruz
%             SN(i).clusterid = CLSTR(j).ID; % dugumun bagli oldugu kume
%             SN(i).role=0; % slave mod '0', CH secilirse master mod '1'
%             SN(i).cond=1; % sensorun durum kodu. canl�(operational) = 1, olu(dead) = 0
%             SN(i).rop=0; % dugumun operasyonel oldugu tur say�s�
%             SN(i).dist_ch=0; % dugumun k�me icesindeki CH a olan uzakligi
%             SN(i).dist_s=0; % dugumun sinke olan uzakligi
%             SN(i).tel=0; % dugumun kac kere CH secildigi
%             SN(i).rn=0; % turdaki CH olan dugum
%             SN(i).chid=0; %dugumun baglandigi CH dugumu
%         end
%     end
%
%     hold on;
%     figure(1)
%     plot(x,y,xm,ym,SN(i).x,SN(i).y,'ob',sinkx,sinky,'*r');
%     title 'BLE Sensor Network';
%     xlabel '(m)';
%     ylabel '(m)';
% end
% merkezleri olusturma ve cizme
%merkez = merkezCiz(struct (CLSTR));

%Sensor datasini ekleyelim
load('SN_1000_12.mat');
load('CLSTR_12.mat');
load('merkez_120_90.mat');

% for i=1:n
%     SN(i).norm_data=0; %
% end
tic

%%%%%% Set-Up Fazi %%%%%%
    cities=clstr;
    locations=zeros(cities,2);
    l=1;
    
    while(l<=cities)
        locations(l,1)=merkez(l).x;
        locations(l,2)=merkez(l).y;
        l=l+1;
    end
    distances =zeros(cities);
    for count1=1:cities,
        for count2 =1:count1,
            x1=locations(count1,1);
            y1=locations(count1,2);
            x2=locations(count2,1);
            y2=locations(count2,2);
            distances(count1,count2)=sqrt((x1-x2)^2+(y1-y2)^2);
            distances(count2,count1)=distances(count1,count2);
        end;
    end;
    
    
    FitnessFcn = @(x) TSP(x,distances);
    
    options=gaoptimset('PopulationType','custom','PopInitRange',[1;cities]);

    options=gaoptimset(options,'CreationFcn',@CreationFcn,'CrossoverFcn',@CrossoverFcn,'MutationFcn',@MutationFcn,'Generations',500,'PopulationSize',60,'StallGenLimit',200,'Vectorized','on');
    
    numberOfVariables=cities;

    [Temp_Route,fval,reason,output]=ga(FitnessFcn,numberOfVariables,[],[],[],[],[],[],[],options);
    Route=Temp_Route{1,1};
    for m=1:clstr
        merkez(m).queue=Route(m);
    end

while operating_nodes>0
    % Mevcut tur bilgini basalim %
    rnd

    energy=0;
    
    %siralamaya g�re sensorleri kumeleri ile isliyoruz%
    
    for p=1:clstr
        for r=1:clstr
            %Kume(:)=[];
            if(merkez(r).queue==p)
                %bu k�meyi �al��t�raca��z.%
                %clusterid=r olacak
                u=1;
                for s=1:n
                    if(SN(s).clusterid==r)
                        Kume(u).id=u;
                        Kume(u).x=SN(s).x;
                        Kume(u).y=SN(s).y;
                        Kume(u).E = SN(s).E;
                        Kume(u).clusterid = SN(s).clusterid;
                        Kume(u).role=SN(s).role;
                        Kume(u).cond=SN(s).cond;
                        Kume(u).rop=SN(s).rop;
                        Kume(u).dist_ch=SN(s).dist_ch;
                        Kume(u).dist_s=SN(s).dist_s;
                        Kume(u).tel=SN(s).tel;
                        Kume(u).rn=SN(s).rn;
                        Kume(u).chid=SN(s).chid;
                        SN(s).kumeid=Kume(u).id;
                        Kume(u).sinkx=merkez(r).x;
                        Kume(u).sinky=merkez(r).y;
                        Kume(u).norm_data=SN(s).norm_data;
                        u=u+1;
                    end
                end
                %metodu cagir%
                if(sum([Kume(:).cond])>=1)
                    
                    hesapla = steadyState(struct (Kume), merkez(r).x, merkez(r).y, rnd, energy, dead_nodes, operating_nodes,sink_energy);
                    
                    energy=hesapla(1).energy;
                    dead_nodes=hesapla(1).dead_nodes;
                    operating_nodes=hesapla(1).operating_nodes;
                    sink_energy=hesapla(1).sink_energy;
                    
                    %donus de�erlerini atalim%
                    for t=1:u-1
                        for v=1:n
                            if((SN(v).kumeid==t) & (SN(v).clusterid==r))
                                SN(v).E=hesapla(t).E;
                                SN(v).role=hesapla(t).role;
                                SN(v).cond=hesapla(t).cond;
                                SN(v).rop=hesapla(t).rop;
                                SN(v).dist_ch=hesapla(t).dist_ch;
                                SN(v).dist_s=hesapla(t).dist_s;
                                SN(v).tel=hesapla(t).tel;
                                SN(v).rn=hesapla(t).rn;
                                SN(v).chid=hesapla(t).chid;
                                SN(v).norm_data=hesapla(t).norm_data;%27.10.2020 hata i�in kondu
                            end
                        end
                    end
                end

                Kume(:)=[];
            end
        end
    end
    total_energy=total_energy + energy;

    transmissions=transmissions+1;
    
    % Next Round %
    rnd= rnd +1;
    
    tr(transmissions)=operating_nodes;%tur basina aktif olan node sayisi
    op(rnd)=operating_nodes;%tur basina aktif olan node sayisi
    dnod(transmissions)=dead_nodes;% tur ba��na �len node say�s�
    
    if energy>0
        nrg(transmissions)=energy;%tur basina harcanan enerji
    end
    % residual energy for the network
    if energy>0
        nrg(transmissions)=energy;%tur basina harcanan enerji
        residual_energy = residual_energy-energy;
        ren(transmissions)= residual_energy;
        toten(transmissions)= total_energy;
    end
    
end

sum=0;

for i=1:rnd
    sum=nrg(i) + sum;
end

toc
zaman=toc;

% Plotting Simulation Results "Operating Nodes per Round" %
figure(2)
plot(1:rnd,op(1:rnd),'-r','Linewidth',2);
title ({'Operating Nodes per Round';})
xlabel 'Rounds';
ylabel 'Operational Nodclose all';
hold on;
%clear;
%clc;

figure(3)
plot(1:transmissions,ren(1:transmissions),'-r','Linewidth',2);
title ({'Residual Energy of Network per Transmission';})
xlabel 'Transmission';
ylabel 'Energy ( J )';
hold on;

figure(4)
plot(1:transmissions,nrg(1:transmissions),'-r','Linewidth',2);
title ({'Energy consumed per Transmission';})
xlabel 'Transmission';
ylabel 'Energy ( J )';
hold on;

figure(5)
plot(1:transmissions,dnod(1:transmissions),'-r','Linewidth',2);
title ({'Dead nodes per Transmission';})
xlabel 'Transmission';
ylabel 'Node';
hold on;


figure(6)
plot(1:transmissions,toten(1:transmissions),'-r','Linewidth',2);
title ({'Total Energy';})
xlabel 'Transmission';
ylabel 'Node';
hold on;

