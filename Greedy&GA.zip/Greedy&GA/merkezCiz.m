function center = merkezCiz( cluster )
for i=1:length(cluster)
    Merkez(i).id=i;
    Merkez(i).x=cluster(i).centerX;
    Merkez(i).y=cluster(i).centerY;
    Merkez(i).cond=0 
    Merkez(i).queue=0 
end
center=Merkez;
end
