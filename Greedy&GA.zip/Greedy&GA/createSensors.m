function sensor = createSensors(n,xm,ym)

            for i=1:n
              Sensor(i).id=i;
              Sensor(i).x=rand(1,1)*xm;
              Sensor(i).y=rand(1,1)*ym;
            end                
            sensor=Sensor;
end