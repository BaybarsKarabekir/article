function sonuc = steadyState( kume , x, y, rnd, energy, dead_nodes, operating_nodes, sink_energy)

Eelec=50*10^(-9); % units in nanoJoules/bit
ETx=50*10^(-9); % units in Joules/bit
ERx=50*10^(-9); % units in Joules/bit
Eamp=100*10^(-12); % units in pikoJoules/bit/m^2 (amount of energy spent by the amplifier to transmit the bits)
EDA=5*10^(-9); % units in Joules/bit
k=4000; % units in bits

for i=1:length(kume)
    %kume icin Dugumlerin Merkeze Olan Uzakliklari Hesaplanir%    
    if (kume(i).cond==0)
        kume(i).role=0;
    end
end

if( sum([kume(:).role])~= 3 || (kume([kume(:).role]==1).E-kume([kume(:).role]==1).norm_data) <= (kume([kume(:).role]==2).E-kume([kume(:).role]==2).norm_data) || kume([kume(:).role]==1).cond == 0 || kume([kume(:).role]==2).cond == 0)
    for i=1:length(kume)
        %kume icin Dugumlerin Merkeze Olan Uzakliklari Hesaplanir%
        
        if (kume(i).E>0) && (kume(i).cond==1)
            dist(i)=sqrt((kume(i).x-x)^2 + (kume(i).y-y)^2);
            fitness(i).id=i;
            fitness(i).Ekalan=(kume(i).E);
            fitness(i).Euclidean=(dist(i));
            euclidean(i)=fitness(i).Euclidean;
        end
    end
    
    %kume icin Normalizasyon Yapalim%
    for i=1:length(kume)
        fitness(i).norm_data=0;%27.10.2020 hata i�in kondu
        if (kume(i).E>0) && (kume(i).cond==1)
            fitness(i).norm_data=(euclidean(i) - min(euclidean))/(max(euclidean)-min(euclidean));
            fitness(i).f=(kume(i).E)-(fitness(i).norm_data);
            fittness(i)=fitness(i).f;
            kume(i).role=0;
        end
    end
    
    %kume icin CH secimini Gerceklestirelim%

    CH=0;
    [M,CH]=max(fittness(:)); % finds the maximum fitness node to CH
    kume(CH).role=1;
    kume(CH).rn=rnd;	% Assigns the round that the cluster head was elected to the data table
    kume(CH).tel=kume(CH).tel + 1; %kac kere ch secildi
    kume(CH).dist_s=sqrt((kume(CH).sinkx-kume(CH).x)^2 + (kume(CH).sinkx-kume(CH).y)^2); % calculates the distance between the sink and the cluster hea
    kume(CH).norm_data=fitness(CH).norm_data;%27.10.2020 hata i�in kondu
    %end
    second_fittness(:)=fittness(:);%27.10.2020 hata i�in kondu
    second_fittness(CH)=-1;%27.10.2020 hata i�in kondu
    
    if(sum([kume(:).cond])>= 2 )
    CH2=0;%27.10.2020 hata i�in kondu
    [M2,CH2]=max(second_fittness(:)); % finds the maximum fitness node to CH%27.10.2020 hata i�in kondu
    kume(CH2).role=2;%27.10.2020 hata i�in kondu
    kume(CH2).norm_data=fitness(CH2).norm_data;%27.10.2020 hata i�in kondu
    end
    
    for i=1:length(kume)
        if  (((kume(i).role==0)||(kume(i).role==2)) && (kume(i).E>0)  && (kume(i).cond==1)) %27.10.2020 hata i�in kondu
            kume(i).dist_ch=sqrt((kume(CH).x-kume(i).x)^2 + (kume(CH).y-kume(i).y)^2);
            kume(i).chid=CH;
        end
    end
    
end


%Kume icin Enerji Harcama%
for i=1:length(kume)
    if (kume(i).cond==1) && ((kume(i).role==0)||(kume(i).role==2))  
        if kume(i).E>0
            %Sensorlerin veri gondermede harcadiklari enerji
            ETx= Eelec*k + Eamp * k * kume(i).dist_ch^2;
            kume(i).E=kume(i).E - ETx;
            energy=energy+ETx;
            % CH icin veri toplamada harcanan enerji
            if kume(kume(i).chid).E>0 && kume(kume(i).chid).cond==1 && kume(kume(i).chid).role==1
                ERx=(Eelec+EDA)*k;
                energy=energy+ERx;
                kume(kume(i).chid).E=kume(kume(i).chid).E - ERx;
                if kume(kume(i).chid).E<=0  % if cluster heads energy depletes with reception
                    kume(kume(i).chid).cond=0;
                    kume(kume(i).chid).rop=rnd;
                    dead_nodes=dead_nodes +1;
                    operating_nodes= operating_nodes - 1
                end
            end
        end
        
        if kume(i).E<=0       % if nodes energy depletes with transmission
            dead_nodes=dead_nodes +1;
            operating_nodes= operating_nodes - 1
            kume(i).cond=0;
            kume(i).chid=0;
            kume(i).rop=rnd;
        end
        
    elseif(kume(i).cond==1)  && (kume(i).role==1)
        if kume(i).E>0
            ETx= (Eelec+EDA)*k + Eamp * k * kume(i).dist_s^2;
            kume(i).E=kume(i).E - ETx;
            energy=energy+ETx;
            %2.11.2020 tarihinde baz istasyonun harcad��� enerjiyi girelim%
            Sink_ERx= (Eelec+EDA)*k;
            sink_energy=sink_energy+Sink_ERx;
        end
        if  kume(i).E<=0     % if cluster heads energy depletes with transmission
            dead_nodes=dead_nodes +1;
            operating_nodes= operating_nodes - 1
            kume(i).cond=0;
            kume(i).rop=rnd;
        end
    end
end
kume(1).energy=energy;
kume(1).dead_nodes=dead_nodes;
kume(1).operating_nodes=operating_nodes;
kume(1).sink_energy=sink_energy;
sonuc=kume;
end

